package processor.memorysystem;
import generic.*;
import processor.Processor;
import processor.Clock;
import configuration.Configuration;

// public class Cache implements Element{

//     Processor containingProcessor;
//     public Element returningEl;
//     int CLsize, start,end, current;
//     int Cline;
//     int hit, miss;
//     int address, valueToWrite, valueToRead;
//     long latency;
//     CacheLine[] L1Cache;
//     //public Element ReturningEl;

//     public Cache(int size,long latency,Element element, Processor processor){
//         this.CLsize = size;
//         size = CLsize + 1;
//         this.L1Cache = new CacheLine[size];

//         this.containingProcessor = processor;
//         this.returningEl = element;
//         this.start = -1;
//         this.end = -1;
//         this.current = 0;
//         this.Cline = 0;
//         this.hit = 0;
//         this.miss = 0;

//         this.address = -1;
//         this.valueToWrite = 0;
//         this.valueToRead = 0;
//         this.latency = latency;

//         for(int i =0; i< size; i++){
//             L1Cache[i] = new CacheLine();
//         }
//     }


//     public void cacheRead(int address,MemoryReadEvent e){
//         //hit = 0;
//         for(int i = 0; i<current ;i++){
//             Cline = L1Cache[(start+ i) % CLsize].tag;
//             if(Cline == address){
//                 hit = 1;
//                 this.address = address;
//                 valueToRead = L1Cache[(start + i)%CLsize].data;
//                 MemoryReadEvent event = (MemoryReadEvent) e;
//                 MemoryResponseEvent MRE = new MemoryResponseEvent(Clock.getCurrentTime()  ,this,event.getRequestingElement(),valueToRead);
//                 MRE.setVal(0);
//                 Simulator.getEventQueue().addEvent(MRE);
//                 //this.address = address;
//                 return;

//             }
//         }
//         // if(hit == 0){
//         //     handleCacheMiss(address,e);
//         // }
//         handleCacheMiss(address,e);
//     }

//     public void handleCacheMiss(int addr, Event e){
//         hit = 0;
//         miss = 1;
//         address = addr;

//         MemoryReadEvent events = new MemoryReadEvent(Clock.getCurrentTime()+Configuration.mainMemoryLatency,this,containingProcessor.getMainMemory(),address);
//         Simulator.getEventQueue().addEvent(new MemoryReadEvent(Clock.getCurrentTime()+Configuration.mainMemoryLatency,this,containingProcessor.getMainMemory(),address));
//     }

//     public void cacheWrite(int addr, int value){
//         address = addr;
//         valueToWrite = value;
//         hit = 0;
//         for(int i = 0; i< current; i++){
//             Cline = L1Cache[(start+ i) % CLsize].tag;
//             if(Cline == address){
//                 hit = 1;
//                 //write through policy
//                 //MemoryWriteEvent event =new MemoryWriteEvent(Clock.getCurrentTime() + Configuration.mainMemoryLatency,this,containingProcessor.getMainMemory(),address,valueToWrite);
//                 //Simulator.getEventQueue().addEvent(event);

//             }
//         }
//         //if(hit == 0) {
//             MemoryWriteEvent event = new MemoryWriteEvent(Clock.getCurrentTime() + Configuration.mainMemoryLatency ,this,containingProcessor.getMainMemory(),address,valueToWrite);

//             Simulator.getEventQueue().addEvent(new MemoryWriteEvent(Clock.getCurrentTime() + Configuration.mainMemoryLatency ,this,containingProcessor.getMainMemory(),address,valueToWrite));
//         //}
//     }

//     public void handleResponse(MemoryResponseEvent e)
//     {
//         MemoryResponseEvent MRE = new MemoryResponseEvent(Clock.getCurrentTime(),this, returningEl, e.getValue());
//         MRE.setVal(e.getVal());
//         if (e.getVal() == 0 && hit == 0)
//         {
//             if (current >= CLsize)
//             {
//                 L1Cache[start].tag = address;
//                 L1Cache[start].data = MRE.getValue();
//                 start = (start + 1) % CLsize;
//                 end = (end + 1) % CLsize;
//             }
//             else if (current == 0)
//             {
//                 start = 0;
//                 end = 0;
//                 current += 1;
//                 L1Cache[end].tag = address;
//                 L1Cache[end].data = MRE.getValue();
//             }
//             else
//             {
//                 end = (end + 1) % CLsize;
//                 current += 1;
//                 L1Cache[end].tag = address;
//                 L1Cache[end].data = MRE.getValue();
//             } 
//         }
//         else if (e.getVal() == 1 && hit == 1)
//         {
//             for (int i = 0; i < current; i++)
//             {
//                 if (L1Cache[(start + i) % CLsize].tag == address)
//                 {
//                     L1Cache[(start + i) % CLsize].data = valueToWrite;
//                 }
//             }
//             hit = 0;
//         }
//         Simulator.getEventQueue().addEvent(MRE);

//     }

//     @Override
//     public void handleEvent(Event e)
//     {
//         if (e.getEventType() == Event.EventType.MemoryRead)
//         {
//             MemoryReadEvent event = (MemoryReadEvent) e;
//             cacheRead((event.getAddressToReadFrom()), event);
//         }
//         else if (e.getEventType() == Event.EventType.MemoryWrite)
//         {
//             MemoryWriteEvent event = (MemoryWriteEvent) e;
//             cacheWrite(event.getAddressToWriteTo(), event.getValue());
//         }
//         else if(e.getEventType() == Event.EventType.MemoryResponse)
//         {
//             MemoryResponseEvent event = (MemoryResponseEvent) e;
//             handleResponse((MemoryResponseEvent) e);
//         }
//     }
// }






public class Cache implements Element{

    int size,h,t,cur;
    int hit,addr,val;
    long latency;
    CacheLine[] cacheq;
    Processor containingProcessor;
    public Element returningEl;

    public Cache(int size,long latency,Processor p,Element el){
        this.size = size;
        this.cacheq = new CacheLine[size+1];
        for(int i=0;i<size+1;i++) {
			cacheq[i]=new CacheLine();
		}
        this.h = -1;
        this.t = -1;
        this.cur = 0;
        this.latency = latency;
        this.hit = 0;
        this.val = 0;
        this.containingProcessor = p;
        this.addr = -1;
        this.returningEl = el;
    }

    public void cacheRead(int address,MemoryReadEvent e){
        //System.out.printf("cache read addr : %d\n",address);
        if(returningEl==containingProcessor.getMAUnit())    
            System.out.printf("load addr : %d\n",address);
        for(int i=0;i<cur;i++){
            if(cacheq[(h+i)%size].tag==address){
                if(returningEl==containingProcessor.getMAUnit())     
                    System.out.printf("hit addr : %d ,cache val : %d,mem val: %d\n",address,cacheq[(h+i)%size].data,containingProcessor.getMainMemory().getWord(address));
                //System.out.printf("hit %d\n",address);
                MemoryReadEvent event = (MemoryReadEvent) e;
                MemoryResponseEvent MRE = new MemoryResponseEvent(Clock.getCurrentTime(),this,event.getRequestingElement(),cacheq[(h+i)%size].data);
                MRE.setVal(0);
                Simulator.getEventQueue().addEvent(MRE);
                hit = 1;
                addr = address;
                return;
            }
        }
        handleCacheMiss(address,e);
    }
    public void cacheWrite(int address,int value){
        val = value;
        addr = address;
        hit=0;
        System.out.printf("addr : %d , val : %d\n",addr,val);
        for(int i=0;i<cur;i++){
            if(cacheq[(h+i)%size].tag==addr){
                hit = 1;
            }
        }
        Simulator.getEventQueue().addEvent(new MemoryWriteEvent(Clock.getCurrentTime() + Configuration.mainMemoryLatency ,this,containingProcessor.getMainMemory(),address,value));
    }
    public void handleCacheMiss(int address,Event e){
        hit = 0;
        addr = address;
        Simulator.getEventQueue().addEvent(new MemoryReadEvent(Clock.getCurrentTime() + Configuration.mainMemoryLatency ,this,containingProcessor.getMainMemory(),address));
    }
    public void handleResponse(MemoryResponseEvent e){
        MemoryResponseEvent MRE = new MemoryResponseEvent(Clock.getCurrentTime(),this,returningEl,e.getValue());
        if(returningEl==containingProcessor.getMAUnit())     
            System.out.printf("HRE addr : %d , val : %d\n",addr,e.getValue());
        MRE.setVal(e.getVal());
        if(e.getVal()==0&&hit==0){
            if(cur>=size){
                cacheq[h].tag = addr;
                cacheq[h].data = MRE.getValue();
                h = (h+1)%size; 
                t = (t+1)%size;
            }
            else if(cur==0){
                h = 0;
                t = 0;
                cur++;
                cacheq[t].tag = addr;
                cacheq[t].data = MRE.getValue(); 
            }
            else{
                t = (t+1)%size;
                cur++;
                cacheq[t].tag = addr;
                cacheq[t].data = MRE.getValue(); 
            }
        }
        else if(e.getVal()==1&&hit==1){
            System.out.printf("addr:%d,val:%d\n",addr,val);
            for(int i=0;i<cur;i++){
                if(cacheq[(h+i)%size].tag==addr){
                    cacheq[(h+i)%size].data = val;
                }
            }
            hit=0;
        }
        Simulator.getEventQueue().addEvent(MRE);
    }

    @Override
	public void handleEvent(Event e) {
        //System.out.printf("current q size: %d\n",cur);
        if(e.getEventType() == Event.EventType.MemoryRead){
            //System.out.printf("cache read\n");
            MemoryReadEvent event = (MemoryReadEvent)e;
            cacheRead(event.getAddressToReadFrom(),event);
        }
        else if(e.getEventType() == Event.EventType.MemoryWrite){
            //System.out.printf("cache write\n");
            MemoryWriteEvent event = (MemoryWriteEvent)e;
            cacheWrite(event.getAddressToWriteTo(),event.getValue());
        }
        else if(e.getEventType() == Event.EventType.MemoryResponse){
            //System.out.printf("cache response\n");
            handleResponse((MemoryResponseEvent)e);
        }
    }
}